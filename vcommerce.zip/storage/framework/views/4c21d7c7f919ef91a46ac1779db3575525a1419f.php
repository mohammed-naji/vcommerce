<?php $__env->startSection('content'); ?>
    <h2>All Products (<?php echo e($products->count()); ?>)</h2>

    <?php if(session('msg')): ?>
        <div class="alert alert-<?php echo e(session('type')); ?> alert-dismissible fade show">
            <?php echo e(session('msg')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
        </div>
    <?php endif; ?>

    <table class="table table-bordered">
        <tr class="bg-dark text-white">
            <th>ID</th>
            <th>Name</th>
            <th>price</th>
            <th>image</th>
            <th>quantity</th>
            <th>serial_number</th>
            <th>Created At</th>
            <th>Actions</th>
        </tr>

        <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
            
            <td><?php echo e($loop->iteration); ?></td>
            <td><?php echo e($product->name); ?></td>
            <td><?php echo e($product->price); ?></td>
            <td><?php echo e($product->image); ?></td>
            <td><?php echo e($product->quantity); ?></td>
            <td><?php echo e($product->serial_number); ?></td>
            <td><?php echo e($product->created_at->diffForHumans()); ?></td>
            <td>
                <a href="<?php echo e(route('admin.products.edit', $product->id)); ?>" class="btn btn-primary btn-sm">Edit</a>
                <form class="d-inline" action="<?php echo e(route('admin.products.destroy', $product->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('delete'); ?>
                    <button onclick="return confirm('هل انت متاكد اخوي')" class="btn btn-danger btn-sm">Delete</button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="4">No Data Found</td>
            </tr>
        <?php endif; ?>

    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\vcommerce\resources\views/admin/products/index.blade.php ENDPATH**/ ?>