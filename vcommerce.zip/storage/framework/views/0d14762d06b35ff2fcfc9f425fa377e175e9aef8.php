<div class="single-product">
    <div class="product-img">
        <a href="<?php echo e(route('website.product', $product->slug)); ?>">
            <img class="default-img" src="<?php echo e(asset('images/'.$product->image)); ?>" alt="#">
        </a>
        
    </div>
    <div class="product-content">
        <h3><a href="<?php echo e(route('website.product', $product->slug)); ?>"><?php echo e($product->name); ?></a></h3>
        <div class="product-price">
            <span>$<?php echo e($product->price); ?></span>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\vcommerce\resources\views/website/product.blade.php ENDPATH**/ ?>