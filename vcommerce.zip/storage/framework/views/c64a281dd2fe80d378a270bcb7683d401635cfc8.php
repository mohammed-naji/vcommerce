<?php $__env->startSection('content'); ?>
    <h2>All Discounts (<?php echo e($discounts->count()); ?>)</h2>

    <?php if(session('msg')): ?>
        <div class="alert alert-<?php echo e(session('type')); ?> alert-dismissible fade show">
            <?php echo e(session('msg')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
        </div>
    <?php endif; ?>

    <table class="table table-bordered">
        <tr class="bg-dark text-white">
            <th>ID</th>
            <th>Name</th>
            <th>start date</th>
            <th>end date</th>
            <th>percentage</th>
            <th>customers</th>
            <th>Created At</th>
            <th>Actions</th>
        </tr>

        <?php $__empty_1 = true; $__currentLoopData = $discounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $discount): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
            
            <td><?php echo e($loop->iteration); ?></td>
            <td><?php echo e($discount->name); ?></td>
            <td><?php echo e($discount->start_date); ?></td>
            <td><?php echo e($discount->end_date); ?></td>
            <td><?php echo e($discount->percentage); ?></td>
            <td><?php echo e($discount->customers); ?></td>
            <td><?php echo e($discount->created_at->diffForHumans()); ?></td>
            <td>
                <a href="<?php echo e(route('admin.discounts.edit', $discount->id)); ?>" class="btn btn-primary btn-sm">Edit</a>
                <form class="d-inline" action="<?php echo e(route('admin.discounts.destroy', $discount->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('delete'); ?>
                    <button onclick="return confirm('هل انت متاكد اخوي')" class="btn btn-danger btn-sm">Delete</button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="4">No Data Found</td>
            </tr>
        <?php endif; ?>

    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\vcommerce\resources\views/admin/discounts/index.blade.php ENDPATH**/ ?>