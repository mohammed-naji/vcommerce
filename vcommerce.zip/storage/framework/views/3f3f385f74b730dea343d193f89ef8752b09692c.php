<?php $__env->startSection('content'); ?>
    <h2>Update Category : <b class="text-warning"><?php echo e($category->name); ?></b></h2>

    <?php echo $__env->make('admin.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <form action="<?php echo e(route('admin.categories.update', $category->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="mb-3">
            <input type="text" class="form-control" name="name" placeholder="Name" value="<?php echo e(old('name', $category->name)); ?>" />
        </div>

        <button class="btn btn-info btn-lg">Update</button>

    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\vcommerce\resources\views/admin/categories/edit.blade.php ENDPATH**/ ?>