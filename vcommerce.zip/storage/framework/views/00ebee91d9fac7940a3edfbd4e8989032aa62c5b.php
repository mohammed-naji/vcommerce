<?php $__env->startSection('content'); ?>
    <h2>Update discount : <b class="text-warning"><?php echo e($discount->name); ?></b></h2>

    <?php echo $__env->make('admin.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <form action="<?php echo e(route('admin.discounts.update', $discount->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="mb-3">
            <input type="text" class="form-control" name="name" placeholder="Name" value="<?php echo e(old('name', $discount->name)); ?>" />
        </div>

        <div class="mb-3">
            <input type="datetime-local" class="form-control" name="start_date" value="<?php echo e(old('start_date', date('Y-m-d\TH:i', strtotime($discount->start_date)) )); ?>" placeholder="Start Date" />
        </div>

        <div class="mb-3">
            <input type="datetime-local" class="form-control" name="end_date" value="<?php echo e(old('end_date', date('Y-m-d\TH:i', strtotime($discount->end_date)) )); ?>" placeholder="End Date" />
        </div>

        <div class="mb-3">
            <input type="text" class="form-control" name="percentage" value="<?php echo e(old('name', $discount->percentage)); ?>" placeholder="Percentage" />
        </div>

        <div class="mb-3">
            <input type="number" class="form-control" name="customers" value="<?php echo e(old('name', $discount->customers)); ?>" placeholder="Customers" />
        </div>

        <button class="btn btn-info btn-lg">Update</button>

    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\vcommerce\resources\views/admin/discounts/edit.blade.php ENDPATH**/ ?>