<?php $__env->startSection('content'); ?>
    <h2>Add New Discount</h2>

    <?php echo $__env->make('admin.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <form action="<?php echo e(route('admin.discounts.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <div class="mb-3">
            <input type="text" class="form-control" name="name" placeholder="Name" />
        </div>

        <div class="mb-3">
            <input type="datetime-local" class="form-control" name="start_date" placeholder="Start Date" />
        </div>

        <div class="mb-3">
            <input type="datetime-local" class="form-control" name="end_date" placeholder="End Date" />
        </div>

        <div class="mb-3">
            <input type="text" class="form-control" name="percentage" placeholder="Percentage" />
        </div>

        <div class="mb-3">
            <input type="number" class="form-control" name="customers" placeholder="Customers" />
        </div>

        <button class="btn btn-dark btn-lg">Save</button>

    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\vcommerce\resources\views/admin/discounts/create.blade.php ENDPATH**/ ?>