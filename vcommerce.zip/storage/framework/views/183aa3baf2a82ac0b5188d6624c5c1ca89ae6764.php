<?php $__env->startSection('content'); ?>
    <h2>Add New Category</h2>

    <?php echo $__env->make('admin.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <form action="<?php echo e(route('admin.categories.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <div class="mb-3">
            <input type="text" class="form-control" name="name" placeholder="Name" />
        </div>

        <button class="btn btn-dark btn-lg">Save</button>

    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\vcommerce\resources\views/admin/categories/create.blade.php ENDPATH**/ ?>