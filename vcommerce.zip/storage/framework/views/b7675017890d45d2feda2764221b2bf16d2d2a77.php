<?php $__env->startSection('content'); ?>

<section class="my-5">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <img class="w-100" src="<?php echo e(asset('images/'.$product->image)); ?>" alt="">

                <?php
                    $album = explode(',', $product->album);
                ?>
                <?php $__currentLoopData = $album; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <img class="w-25" src="<?php echo e(asset('images/'.$a)); ?>" alt="">
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            </div>

            <div class="col-md-6">

                <?php if(session('success')): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <?php echo e(session('success')); ?>

                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                  </div>
                <?php endif; ?>

                <h1><?php echo e($product->name); ?></h1>
                <h4 class="my-4">Price <?php echo e($product->price); ?>$</h4>
                <p><?php echo e($product->description); ?></p>

                <div class="mt-5">
                    <form class="d-inline" action="<?php echo e(route('website.buy')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="user_id" value="<?php echo e(Auth::id()); ?>" />
                        <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>" />
                        <input type="hidden" name="type" value="cart" />

                        <button class="btn btn-primary">Add To Cart</button>
                    </form>

                    <form class="d-inline" action="<?php echo e(route('website.buy')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="user_id" value="<?php echo e(Auth::id()); ?>" />
                        <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>" />
                        <input type="hidden" name="type" value="wishlist" />

                        <button style="background: #f00" class="btn btn-warning">Add To Wishlist</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('website.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\vcommerce\resources\views/website/show.blade.php ENDPATH**/ ?>